/*
 * yyparse.h (version 1.0)
 *
 * Define the parser control structure for yaccpar enhanced to support multiple
 * YACC-generated parsers in a single runtime. Written by Eric S. Raymond.
 */
#ifndef YYPARSE
#define YYPARSE	yyparse		/* set default name for the parser function */
#endif /* !YYPARSE */

typedef struct
{
	/* user can set these */
	int	(*yylex)();		/* pointer to token-getter function */
	YYSTYPE yylval;			/* put value of current token here */
	int	yydebug;		/* set to 1 to get debugging */

	/* remaining members are read-only */
	YYSTYPE	yyval;			/* value of current production */

	YYSTYPE yyv[ YYMAXDEPTH ];	/* value stack */
	int yys[ YYMAXDEPTH ];		/* state stack */

	YYSTYPE *yypv;			/* top of value stack */
	int *yyps;			/* top of state stack */

	int yystate;			/* current state */
	int yytmp;			/* extra var (lasts between blocks) */

	int yynerrs;			/* number of errors */
	int yyerrflag;			/* error recovery flag */
	int yychar;			/* current input token number */
}
yyparse_t;

/* yyparse.h ends here */
