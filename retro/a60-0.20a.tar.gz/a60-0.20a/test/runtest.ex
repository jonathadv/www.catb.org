
	echo fakul.a60 
	/a60 fakul.a60

	echo outnum.a60 
	/a60 outnum.a60

	echo irnum.a60 
	/a60 irnum.a60

	echo outstr.a60 
	/a60 outstr.a60

	echo jdev.a60 
	/a60 jdev.a60

	echo cbname.a60 
	/a60 cbname.a60

	echo ack.a60 
	/a60 ack.a60

	echo queen.a60 
	/a60 queen.a60

	echo logic1.a60
	/a60 logic1.a60

	echo sin.a60
	/a60 sin.a60

	echo rmath.a60
	/a60 rmath.a60

	echo goto.a60
	/a60 goto.a60

	echo ifstmt.a60
	/a60 ifstmt.a60

	echo for.a60
	/a60 for.a60

	echo procp.a60
	/a60 procp.a60

	echo sort.a60
	/a60 sort.a60

	echo iarr.a60
	/a60 iarr.a60

	echo mama.a60
	/a60 mama.a60

	echo entier.a60
	/a60 entier.a60

	echo igral.a60
	/a60 igral.a60

	echo own.a60
	/a60 own.a60

	echo switch.a60
	/a60 switch.a60

	echo dirty.a60
	/a60 dirty.a60

	echo syntax.a60
	/a60 syntax.a60
