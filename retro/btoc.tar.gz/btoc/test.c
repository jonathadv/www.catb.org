
word 
davol(one, two, three)
word            one, two, three;
{
   switch (one)
   {
   case 1L:
      return 1L;
      break;
   case 2L:
      return 2L;
      break;
   case 3L:
      return 3L;
      break;
   case 4L:
      return 4L;
      break;
   default:
      return 0L;
   }
   return -1L;
}
