## Test read and write
echo "RECEIVE" | comit receive.co
