/* insightful comment */

#include <header.h>

void function(struct *frobnicator) 
{

  if(frobnicator->member1) 
  {	  
    do_eek();
  } 
  else
  {
    do_sheesh();
  }
}
