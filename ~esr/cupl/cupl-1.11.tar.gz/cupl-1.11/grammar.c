/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 19 "cupl.y"

#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <stdlib.h>

#ifdef PARSEDEBUG
static int statement_count;
#endif /* PARSEDEBUG */

#include "cupl.h"

#ifdef YYBISON
 extern int yylex();	// FIXME: probably not the right place
int yydebug;
#endif /* YYBISON */

#line 89 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    ABS = 258,                     /* ABS  */
    ALL = 259,                     /* ALL  */
    ALLOCATE = 260,                /* ALLOCATE  */
    AND = 261,                     /* AND  */
    ATAN = 262,                    /* ATAN  */
    BLOCK = 263,                   /* BLOCK  */
    BY = 264,                      /* BY  */
    COMMENT = 265,                 /* COMMENT  */
    COS = 266,                     /* COS  */
    DEC = 267,                     /* DEC  */
    DET = 268,                     /* DET  */
    DOT = 269,                     /* DOT  */
    ELSE = 270,                    /* ELSE  */
    END = 271,                     /* END  */
    EXP = 272,                     /* EXP  */
    FLOOR = 273,                   /* FLOOR  */
    FOR = 274,                     /* FOR  */
    GE = 275,                      /* GE  */
    GO = 276,                      /* GO  */
    GT = 277,                      /* GT  */
    IDN = 278,                     /* IDN  */
    IF = 279,                      /* IF  */
    INC = 280,                     /* INC  */
    INV = 281,                     /* INV  */
    LE = 282,                      /* LE  */
    LET = 283,                     /* LET  */
    LN = 284,                      /* LN  */
    LOG = 285,                     /* LOG  */
    LT = 286,                      /* LT  */
    MAX = 287,                     /* MAX  */
    MIN = 288,                     /* MIN  */
    NE = 289,                      /* NE  */
    OR = 290,                      /* OR  */
    PERFORM = 291,                 /* PERFORM  */
    POSMAX = 292,                  /* POSMAX  */
    POSMIN = 293,                  /* POSMIN  */
    RAND = 294,                    /* RAND  */
    READ = 295,                    /* READ  */
    SGM = 296,                     /* SGM  */
    SIN = 297,                     /* SIN  */
    SQRT = 298,                    /* SQRT  */
    STOP = 299,                    /* STOP  */
    THEN = 300,                    /* THEN  */
    TIMES = 301,                   /* TIMES  */
    TO = 302,                      /* TO  */
    TRC = 303,                     /* TRC  */
    TRN = 304,                     /* TRN  */
    UNTIL = 305,                   /* UNTIL  */
    WATCH = 306,                   /* WATCH  */
    WHILE = 307,                   /* WHILE  */
    WRITE = 308,                   /* WRITE  */
    DATA = 309,                    /* DATA  */
    POWER = 310,                   /* POWER  */
    STRING = 311,                  /* STRING  */
    NUMBER = 312,                  /* NUMBER  */
    IDENTIFIER = 313,              /* IDENTIFIER  */
    TITLE = 314,                   /* TITLE  */
    LPAREN = 315,                  /* LPAREN  */
    RPAREN = 316,                  /* RPAREN  */
    PLUS = 317,                    /* PLUS  */
    MINUS = 318,                   /* MINUS  */
    MULTIPLY = 319,                /* MULTIPLY  */
    DIVIDE = 320,                  /* DIVIDE  */
    EQUAL = 321,                   /* EQUAL  */
    PERIOD = 322,                  /* PERIOD  */
    COMMA = 323,                   /* COMMA  */
    FWRITE = 324,                  /* FWRITE  */
    OG = 325,                      /* OG  */
    UMINUS = 326,                  /* UMINUS  */
    SUBSCRIPT = 327,               /* SUBSCRIPT  */
    STATEMENT = 328,               /* STATEMENT  */
    VARLIST = 329,                 /* VARLIST  */
    FORLIST = 330,                 /* FORLIST  */
    LABEL = 331,                   /* LABEL  */
    IFELSE = 332,                  /* IFELSE  */
    DIMENSION = 333,               /* DIMENSION  */
    ISLICE = 334,                  /* ISLICE  */
    JSLICE = 335,                  /* JSLICE  */
    ITERATE = 336,                 /* ITERATE  */
    FROM = 337,                    /* FROM  */
    TRIPLE = 338                   /* TRIPLE  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define ABS 258
#define ALL 259
#define ALLOCATE 260
#define AND 261
#define ATAN 262
#define BLOCK 263
#define BY 264
#define COMMENT 265
#define COS 266
#define DEC 267
#define DET 268
#define DOT 269
#define ELSE 270
#define END 271
#define EXP 272
#define FLOOR 273
#define FOR 274
#define GE 275
#define GO 276
#define GT 277
#define IDN 278
#define IF 279
#define INC 280
#define INV 281
#define LE 282
#define LET 283
#define LN 284
#define LOG 285
#define LT 286
#define MAX 287
#define MIN 288
#define NE 289
#define OR 290
#define PERFORM 291
#define POSMAX 292
#define POSMIN 293
#define RAND 294
#define READ 295
#define SGM 296
#define SIN 297
#define SQRT 298
#define STOP 299
#define THEN 300
#define TIMES 301
#define TO 302
#define TRC 303
#define TRN 304
#define UNTIL 305
#define WATCH 306
#define WHILE 307
#define WRITE 308
#define DATA 309
#define POWER 310
#define STRING 311
#define NUMBER 312
#define IDENTIFIER 313
#define TITLE 314
#define LPAREN 315
#define RPAREN 316
#define PLUS 317
#define MINUS 318
#define MULTIPLY 319
#define DIVIDE 320
#define EQUAL 321
#define PERIOD 322
#define COMMA 323
#define FWRITE 324
#define OG 325
#define UMINUS 326
#define SUBSCRIPT 327
#define STATEMENT 328
#define VARLIST 329
#define FORLIST 330
#define LABEL 331
#define IFELSE 332
#define DIMENSION 333
#define ISLICE 334
#define JSLICE 335
#define ITERATE 336
#define FROM 337
#define TRIPLE 338

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 40 "cupl.y"

    struct edon	*node;

#line 312 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_ABS = 3,                        /* ABS  */
  YYSYMBOL_ALL = 4,                        /* ALL  */
  YYSYMBOL_ALLOCATE = 5,                   /* ALLOCATE  */
  YYSYMBOL_AND = 6,                        /* AND  */
  YYSYMBOL_ATAN = 7,                       /* ATAN  */
  YYSYMBOL_BLOCK = 8,                      /* BLOCK  */
  YYSYMBOL_BY = 9,                         /* BY  */
  YYSYMBOL_COMMENT = 10,                   /* COMMENT  */
  YYSYMBOL_COS = 11,                       /* COS  */
  YYSYMBOL_DEC = 12,                       /* DEC  */
  YYSYMBOL_DET = 13,                       /* DET  */
  YYSYMBOL_DOT = 14,                       /* DOT  */
  YYSYMBOL_ELSE = 15,                      /* ELSE  */
  YYSYMBOL_END = 16,                       /* END  */
  YYSYMBOL_EXP = 17,                       /* EXP  */
  YYSYMBOL_FLOOR = 18,                     /* FLOOR  */
  YYSYMBOL_FOR = 19,                       /* FOR  */
  YYSYMBOL_GE = 20,                        /* GE  */
  YYSYMBOL_GO = 21,                        /* GO  */
  YYSYMBOL_GT = 22,                        /* GT  */
  YYSYMBOL_IDN = 23,                       /* IDN  */
  YYSYMBOL_IF = 24,                        /* IF  */
  YYSYMBOL_INC = 25,                       /* INC  */
  YYSYMBOL_INV = 26,                       /* INV  */
  YYSYMBOL_LE = 27,                        /* LE  */
  YYSYMBOL_LET = 28,                       /* LET  */
  YYSYMBOL_LN = 29,                        /* LN  */
  YYSYMBOL_LOG = 30,                       /* LOG  */
  YYSYMBOL_LT = 31,                        /* LT  */
  YYSYMBOL_MAX = 32,                       /* MAX  */
  YYSYMBOL_MIN = 33,                       /* MIN  */
  YYSYMBOL_NE = 34,                        /* NE  */
  YYSYMBOL_OR = 35,                        /* OR  */
  YYSYMBOL_PERFORM = 36,                   /* PERFORM  */
  YYSYMBOL_POSMAX = 37,                    /* POSMAX  */
  YYSYMBOL_POSMIN = 38,                    /* POSMIN  */
  YYSYMBOL_RAND = 39,                      /* RAND  */
  YYSYMBOL_READ = 40,                      /* READ  */
  YYSYMBOL_SGM = 41,                       /* SGM  */
  YYSYMBOL_SIN = 42,                       /* SIN  */
  YYSYMBOL_SQRT = 43,                      /* SQRT  */
  YYSYMBOL_STOP = 44,                      /* STOP  */
  YYSYMBOL_THEN = 45,                      /* THEN  */
  YYSYMBOL_TIMES = 46,                     /* TIMES  */
  YYSYMBOL_TO = 47,                        /* TO  */
  YYSYMBOL_TRC = 48,                       /* TRC  */
  YYSYMBOL_TRN = 49,                       /* TRN  */
  YYSYMBOL_UNTIL = 50,                     /* UNTIL  */
  YYSYMBOL_WATCH = 51,                     /* WATCH  */
  YYSYMBOL_WHILE = 52,                     /* WHILE  */
  YYSYMBOL_WRITE = 53,                     /* WRITE  */
  YYSYMBOL_DATA = 54,                      /* DATA  */
  YYSYMBOL_POWER = 55,                     /* POWER  */
  YYSYMBOL_STRING = 56,                    /* STRING  */
  YYSYMBOL_NUMBER = 57,                    /* NUMBER  */
  YYSYMBOL_IDENTIFIER = 58,                /* IDENTIFIER  */
  YYSYMBOL_TITLE = 59,                     /* TITLE  */
  YYSYMBOL_LPAREN = 60,                    /* LPAREN  */
  YYSYMBOL_61_ = 61,                       /* ')'  */
  YYSYMBOL_RPAREN = 62,                    /* RPAREN  */
  YYSYMBOL_63_ = 63,                       /* '('  */
  YYSYMBOL_PLUS = 64,                      /* PLUS  */
  YYSYMBOL_65_ = 65,                       /* '+'  */
  YYSYMBOL_MINUS = 66,                     /* MINUS  */
  YYSYMBOL_67_ = 67,                       /* '-'  */
  YYSYMBOL_MULTIPLY = 68,                  /* MULTIPLY  */
  YYSYMBOL_69_ = 69,                       /* '*'  */
  YYSYMBOL_DIVIDE = 70,                    /* DIVIDE  */
  YYSYMBOL_71_ = 71,                       /* '/'  */
  YYSYMBOL_EQUAL = 72,                     /* EQUAL  */
  YYSYMBOL_73_ = 73,                       /* '='  */
  YYSYMBOL_PERIOD = 74,                    /* PERIOD  */
  YYSYMBOL_75_ = 75,                       /* '.'  */
  YYSYMBOL_COMMA = 76,                     /* COMMA  */
  YYSYMBOL_77_ = 77,                       /* ','  */
  YYSYMBOL_FWRITE = 78,                    /* FWRITE  */
  YYSYMBOL_OG = 79,                        /* OG  */
  YYSYMBOL_UMINUS = 80,                    /* UMINUS  */
  YYSYMBOL_SUBSCRIPT = 81,                 /* SUBSCRIPT  */
  YYSYMBOL_STATEMENT = 82,                 /* STATEMENT  */
  YYSYMBOL_VARLIST = 83,                   /* VARLIST  */
  YYSYMBOL_FORLIST = 84,                   /* FORLIST  */
  YYSYMBOL_LABEL = 85,                     /* LABEL  */
  YYSYMBOL_IFELSE = 86,                    /* IFELSE  */
  YYSYMBOL_DIMENSION = 87,                 /* DIMENSION  */
  YYSYMBOL_ISLICE = 88,                    /* ISLICE  */
  YYSYMBOL_JSLICE = 89,                    /* JSLICE  */
  YYSYMBOL_ITERATE = 90,                   /* ITERATE  */
  YYSYMBOL_FROM = 91,                      /* FROM  */
  YYSYMBOL_TRIPLE = 92,                    /* TRIPLE  */
  YYSYMBOL_YYACCEPT = 93,                  /* $accept  */
  YYSYMBOL_program = 94,                   /* program  */
  YYSYMBOL_prog = 95,                      /* prog  */
  YYSYMBOL_command = 96,                   /* command  */
  YYSYMBOL_cond = 97,                      /* cond  */
  YYSYMBOL_ditem = 98,                     /* ditem  */
  YYSYMBOL_datal = 99,                     /* datal  */
  YYSYMBOL_gosub = 100,                    /* gosub  */
  YYSYMBOL_perform = 101,                  /* perform  */
  YYSYMBOL_iter = 102,                     /* iter  */
  YYSYMBOL_triple = 103,                   /* triple  */
  YYSYMBOL_expl = 104,                     /* expl  */
  YYSYMBOL_guard = 105,                    /* guard  */
  YYSYMBOL_rel = 106,                      /* rel  */
  YYSYMBOL_simple = 107,                   /* simple  */
  YYSYMBOL_readl = 108,                    /* readl  */
  YYSYMBOL_writel = 109,                   /* writel  */
  YYSYMBOL_witem = 110,                    /* witem  */
  YYSYMBOL_allocl = 111,                   /* allocl  */
  YYSYMBOL_alloc = 112,                    /* alloc  */
  YYSYMBOL_varlist = 113,                  /* varlist  */
  YYSYMBOL_expr = 114,                     /* expr  */
  YYSYMBOL_maxl = 115,                     /* maxl  */
  YYSYMBOL_minl = 116,                     /* minl  */
  YYSYMBOL_subscr = 117                    /* subscr  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  75
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   740

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  93
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  25
/* YYNRULES -- Number of rules.  */
#define YYNRULES  107
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  255

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   338


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      63,    61,    69,    65,    77,    67,    75,    71,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    73,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    62,    64,    66,    68,
      70,    72,    74,    76,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    94,    94,    97,   104,   112,   117,   118,   119,   120,
     121,   122,   123,   126,   128,   130,   134,   135,   138,   139,
     140,   143,   146,   147,   148,   149,   151,   153,   157,   158,
     159,   162,   166,   167,   168,   169,   178,   179,   180,   183,
     184,   185,   186,   187,   188,   193,   194,   195,   196,   197,
     198,   199,   200,   201,   202,   203,   206,   207,   210,   211,
     214,   215,   216,   217,   220,   221,   224,   226,   230,   231,
     236,   237,   239,   240,   241,   242,   243,   244,   245,   247,
     248,   250,   251,   252,   253,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   263,   264,   265,   266,   268,   269,
     272,   273,   276,   277,   280,   282,   284,   286
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "ABS", "ALL",
  "ALLOCATE", "AND", "ATAN", "BLOCK", "BY", "COMMENT", "COS", "DEC", "DET",
  "DOT", "ELSE", "END", "EXP", "FLOOR", "FOR", "GE", "GO", "GT", "IDN",
  "IF", "INC", "INV", "LE", "LET", "LN", "LOG", "LT", "MAX", "MIN", "NE",
  "OR", "PERFORM", "POSMAX", "POSMIN", "RAND", "READ", "SGM", "SIN",
  "SQRT", "STOP", "THEN", "TIMES", "TO", "TRC", "TRN", "UNTIL", "WATCH",
  "WHILE", "WRITE", "DATA", "POWER", "STRING", "NUMBER", "IDENTIFIER",
  "TITLE", "LPAREN", "')'", "RPAREN", "'('", "PLUS", "'+'", "MINUS", "'-'",
  "MULTIPLY", "'*'", "DIVIDE", "'/'", "EQUAL", "'='", "PERIOD", "'.'",
  "COMMA", "','", "FWRITE", "OG", "UMINUS", "SUBSCRIPT", "STATEMENT",
  "VARLIST", "FORLIST", "LABEL", "IFELSE", "DIMENSION", "ISLICE", "JSLICE",
  "ITERATE", "FROM", "TRIPLE", "$accept", "program", "prog", "command",
  "cond", "ditem", "datal", "gosub", "perform", "iter", "triple", "expl",
  "guard", "rel", "simple", "readl", "writel", "witem", "allocl", "alloc",
  "varlist", "expr", "maxl", "minl", "subscr", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-207)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  ((Yyn) == YYTABLE_NINF)

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     468,   -43,  -207,   -41,  -207,   -24,   372,   -23,   -10,    -9,
      -3,  -207,    -2,    48,   -47,     0,  -207,     6,  -207,   468,
    -207,   324,  -207,  -207,   -13,  -207,   -35,    77,    -1,    24,
      25,    26,    42,    44,    45,    46,  -207,    51,    53,    55,
      58,    63,    65,    69,    71,    73,    87,    88,    90,  -207,
      91,   372,   372,    -8,     3,    93,  -207,   108,    38,  -207,
     -14,  -207,    61,  -207,  -207,  -207,  -207,    97,  -207,    79,
    -207,    86,   -44,  -207,   468,  -207,  -207,   103,   372,   372,
     -26,   372,   -43,   372,   152,   372,   372,   372,   372,   372,
     372,   372,   372,   372,   372,   372,   372,   372,   372,   372,
     372,   372,   372,   372,   219,    68,   117,   172,   172,   372,
     372,   372,   372,   372,   372,   372,   372,   372,   372,   372,
     372,   372,   372,   372,    -3,    -2,  -207,    54,   121,   -47,
    -207,  -207,   101,  -207,  -207,  -207,   125,  -207,   669,  -207,
     179,   204,   284,   357,   463,   524,   535,   542,   553,   470,
     481,   560,   571,   578,   589,   596,   607,   614,   625,   104,
     252,  -207,  -207,   164,  -207,  -207,   669,   669,   669,   669,
     669,   127,   -37,   -37,   117,   117,   669,   669,   669,  -207,
    -207,  -207,  -207,  -207,   420,  -207,   372,  -207,  -207,  -207,
    -207,   372,  -207,  -207,  -207,  -207,   372,   372,  -207,  -207,
    -207,  -207,  -207,  -207,  -207,  -207,   372,  -207,   267,   172,
     372,   106,  -207,    75,   632,   643,   488,   130,   499,   134,
     650,   137,   661,  -207,   430,   420,   372,   372,   420,  -207,
    -207,  -207,   372,  -207,   372,  -207,  -207,  -207,  -207,   372,
    -207,   506,   102,    76,  -207,  -207,  -207,   517,   372,   372,
     372,   669,   669,   668,  -207
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       5,     0,     9,     0,    10,     0,     0,     0,     0,     0,
       0,    55,     0,    63,     0,     0,    12,     0,     2,     5,
       7,    22,     8,     6,     0,    53,    65,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    79,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    70,
      71,     0,     0,     0,    36,     0,    80,     0,     0,    21,
      57,    50,    69,    54,    51,    62,    60,     0,    52,    59,
      16,     0,    20,    11,     5,     1,     3,     0,     0,     0,
       0,     0,     0,     0,    48,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    75,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    61,    63,     0,     0,
      19,     4,     0,    25,    24,    23,     0,    64,    47,    49,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    72,    14,    13,    37,    38,    42,    44,    41,    43,
      40,    78,    73,    74,    76,    77,    39,    46,    45,    56,
      68,    58,    17,    18,     0,    66,     0,    81,    82,    83,
      90,     0,    84,    85,    92,    86,     0,     0,    93,    94,
      89,    95,    88,    87,    96,    97,     0,   104,     0,     0,
       0,    35,    26,    34,     0,     0,   101,     0,   103,     0,
       0,     0,     0,    15,     0,     0,     0,     0,     0,    27,
      67,    91,     0,    98,     0,    99,   107,   106,   105,     0,
      33,    34,     0,    30,    32,   100,   102,     0,     0,     0,
       0,    29,    28,     0,    31
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -207,  -207,   -16,   173,  -207,  -207,   -68,  -207,  -207,  -207,
    -207,  -206,   -52,   -63,  -106,    84,    72,  -207,   119,  -207,
      78,   -21,   -22,   -25,  -207
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,    17,    18,    19,    20,    72,    73,    21,    22,   229,
     211,   212,    53,    54,    23,    61,    68,    69,    25,    26,
      63,    55,   217,   219,    56
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      80,   162,   163,    76,   130,     1,    75,   107,     2,   109,
      70,    71,     3,    70,    71,    24,     4,    27,   116,   240,
     135,     5,   244,    28,     6,     7,   133,   134,     8,   116,
     105,   106,   119,   129,   120,    57,     9,   108,   110,   117,
      10,   118,    82,   119,    11,   120,   164,   165,    58,    59,
      81,    12,    64,    13,    14,    60,    62,    84,   131,    16,
     136,   183,   138,   124,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   160,   226,   249,    83,    85,    86,    87,
     166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   223,    65,    88,    66,    89,    90,    91,
      65,   123,    66,   111,    92,   112,    93,   122,    94,    67,
     113,    95,   227,   116,   114,    67,    96,   115,    97,   161,
     116,   116,    98,   117,    99,   118,   100,   119,   125,   120,
     117,   117,   118,   118,   119,   119,   120,   120,   116,   248,
     101,   102,   228,   103,   104,   126,   127,   116,   117,   128,
     118,   132,   119,   213,   120,   214,   121,   117,   139,   118,
     215,   119,   116,   120,   184,   216,   218,     1,   182,   209,
     116,   206,    -1,   225,     3,   220,   185,   222,    74,   224,
     117,   233,   118,     5,   119,   235,   120,     7,   237,   181,
       8,   137,   186,   180,   241,   242,   243,   241,   179,   246,
     245,   216,    10,   218,     0,     0,    11,     0,   247,     0,
       0,     0,    29,    12,     0,    13,    30,   251,   252,   253,
      31,     0,    32,    33,   116,     0,    34,    35,     0,     0,
     187,     0,    36,     0,   117,    37,   118,     0,   119,    38,
     120,    39,    40,     0,     0,     0,    41,    42,    43,   116,
      44,    45,    46,     0,     0,   188,     0,    47,    48,   117,
      29,   118,     0,   119,    30,   120,    49,    50,    31,     0,
      32,    33,    51,     0,    34,    35,    52,     0,   159,     0,
      36,     0,     0,    37,     0,     0,     0,    38,     0,    39,
      40,     0,     0,     0,    41,    42,    43,   116,    44,    45,
      46,     0,     0,   207,     0,    47,    48,   117,     0,   118,
       0,   119,     0,   120,    49,    50,     0,    29,     0,   208,
      51,    30,     0,     0,    52,    31,   221,    32,    33,   116,
       0,    34,    35,    77,     0,   189,     0,    36,     0,   117,
      37,   118,     0,   119,    38,   120,    39,    40,     0,     0,
       0,    41,    42,    43,     0,    44,    45,    46,     0,     0,
       0,     0,    47,    48,    78,    29,    79,     0,     0,    30,
       0,    49,    50,    31,     0,    32,    33,    51,     0,    34,
      35,    52,     0,     0,     0,    36,     0,     0,    37,     0,
       0,     0,    38,     0,    39,    40,     0,     0,     0,    41,
      42,    43,   116,    44,    45,    46,     0,     0,   190,     0,
      47,    48,   117,    29,   118,     0,   119,    30,   120,    49,
      50,    31,     0,    32,    33,    51,     0,    34,    35,    52,
       0,     0,     0,    36,     0,     0,    37,     0,     0,     0,
      38,     0,    39,    40,     0,     0,     0,    41,    42,    43,
       0,    44,    45,    46,     0,     0,     0,     0,    47,    48,
       0,     0,     0,     1,     0,     0,     2,    49,    50,     0,
       3,     0,     0,   210,     4,   116,     0,    52,     0,     5,
       0,   161,     6,     7,     0,   117,     8,   118,     0,   119,
       0,   120,     0,     0,     9,     0,     0,   239,    10,     0,
       0,     0,    11,     0,     0,     0,     0,     0,   116,    12,
       0,    13,    14,     0,     0,   116,    15,    16,   117,     0,
     118,     0,   119,     0,   120,   117,   116,   118,     0,   119,
     191,   120,     0,   116,     0,     0,   117,   196,   118,     0,
     119,     0,   120,   117,   116,   118,     0,   119,   197,   120,
       0,   116,     0,     0,   117,   232,   118,     0,   119,     0,
     120,   117,   116,   118,     0,   119,   234,   120,     0,   116,
       0,     0,   117,   228,   118,   192,   119,     0,   120,   117,
     116,   118,     0,   119,   250,   120,   193,   116,     0,     0,
     117,     0,   118,   194,   119,     0,   120,   117,   116,   118,
       0,   119,     0,   120,   195,   116,     0,     0,   117,     0,
     118,   198,   119,     0,   120,   117,   116,   118,     0,   119,
       0,   120,   199,   116,     0,     0,   117,     0,   118,   200,
     119,     0,   120,   117,   116,   118,     0,   119,     0,   120,
     201,   116,     0,     0,   117,     0,   118,   202,   119,     0,
     120,   117,   116,   118,     0,   119,     0,   120,   203,   116,
       0,     0,   117,     0,   118,   204,   119,     0,   120,   117,
     116,   118,     0,   119,     0,   120,   205,   116,     0,     0,
     117,     0,   118,   230,   119,     0,   120,   117,   116,   118,
       0,   119,     0,   120,   231,   116,     0,     0,   117,     0,
     118,   236,   119,     0,   120,   117,   116,   118,     0,   119,
       0,   120,   238,   116,   116,     0,   117,     0,   118,   254,
     119,     0,   120,   117,   117,   118,   118,   119,   119,   120,
     120
};

static const yytype_int16 yycheck[] =
{
      21,   107,   108,    19,    72,     5,     0,    15,     8,     6,
      57,    58,    12,    57,    58,    58,    16,    58,    55,   225,
      46,    21,   228,    47,    24,    25,    78,    79,    28,    55,
      51,    52,    69,    77,    71,    58,    36,    45,    35,    65,
      40,    67,    77,    69,    44,    71,   109,   110,    58,    58,
      63,    51,     4,    53,    54,    58,    58,    58,    74,    59,
      81,   129,    83,    77,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,     9,     9,     9,    63,    63,    63,
     111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
     121,   122,   123,   209,    56,    63,    58,    63,    63,    63,
      56,    73,    58,    20,    63,    22,    63,     9,    63,    71,
      27,    63,    47,    55,    31,    71,    63,    34,    63,    61,
      55,    55,    63,    65,    63,    67,    63,    69,    77,    71,
      65,    65,    67,    67,    69,    69,    71,    71,    55,    47,
      63,    63,    77,    63,    63,    58,    77,    55,    65,    73,
      67,    58,    69,   184,    71,   186,    73,    65,    16,    67,
     191,    69,    55,    71,    73,   196,   197,     5,    57,    15,
      55,    77,    55,    77,    12,   206,    61,   208,    15,   210,
      65,    61,    67,    21,    69,    61,    71,    25,    61,   127,
      28,    82,    77,   125,   225,   226,   227,   228,   124,   234,
     232,   232,    40,   234,    -1,    -1,    44,    -1,   239,    -1,
      -1,    -1,     3,    51,    -1,    53,     7,   248,   249,   250,
      11,    -1,    13,    14,    55,    -1,    17,    18,    -1,    -1,
      61,    -1,    23,    -1,    65,    26,    67,    -1,    69,    30,
      71,    32,    33,    -1,    -1,    -1,    37,    38,    39,    55,
      41,    42,    43,    -1,    -1,    61,    -1,    48,    49,    65,
       3,    67,    -1,    69,     7,    71,    57,    58,    11,    -1,
      13,    14,    63,    -1,    17,    18,    67,    -1,    69,    -1,
      23,    -1,    -1,    26,    -1,    -1,    -1,    30,    -1,    32,
      33,    -1,    -1,    -1,    37,    38,    39,    55,    41,    42,
      43,    -1,    -1,    61,    -1,    48,    49,    65,    -1,    67,
      -1,    69,    -1,    71,    57,    58,    -1,     3,    -1,    77,
      63,     7,    -1,    -1,    67,    11,    69,    13,    14,    55,
      -1,    17,    18,    19,    -1,    61,    -1,    23,    -1,    65,
      26,    67,    -1,    69,    30,    71,    32,    33,    -1,    -1,
      -1,    37,    38,    39,    -1,    41,    42,    43,    -1,    -1,
      -1,    -1,    48,    49,    50,     3,    52,    -1,    -1,     7,
      -1,    57,    58,    11,    -1,    13,    14,    63,    -1,    17,
      18,    67,    -1,    -1,    -1,    23,    -1,    -1,    26,    -1,
      -1,    -1,    30,    -1,    32,    33,    -1,    -1,    -1,    37,
      38,    39,    55,    41,    42,    43,    -1,    -1,    61,    -1,
      48,    49,    65,     3,    67,    -1,    69,     7,    71,    57,
      58,    11,    -1,    13,    14,    63,    -1,    17,    18,    67,
      -1,    -1,    -1,    23,    -1,    -1,    26,    -1,    -1,    -1,
      30,    -1,    32,    33,    -1,    -1,    -1,    37,    38,    39,
      -1,    41,    42,    43,    -1,    -1,    -1,    -1,    48,    49,
      -1,    -1,    -1,     5,    -1,    -1,     8,    57,    58,    -1,
      12,    -1,    -1,    63,    16,    55,    -1,    67,    -1,    21,
      -1,    61,    24,    25,    -1,    65,    28,    67,    -1,    69,
      -1,    71,    -1,    -1,    36,    -1,    -1,    77,    40,    -1,
      -1,    -1,    44,    -1,    -1,    -1,    -1,    -1,    55,    51,
      -1,    53,    54,    -1,    -1,    55,    58,    59,    65,    -1,
      67,    -1,    69,    -1,    71,    65,    55,    67,    -1,    69,
      77,    71,    -1,    55,    -1,    -1,    65,    77,    67,    -1,
      69,    -1,    71,    65,    55,    67,    -1,    69,    77,    71,
      -1,    55,    -1,    -1,    65,    77,    67,    -1,    69,    -1,
      71,    65,    55,    67,    -1,    69,    77,    71,    -1,    55,
      -1,    -1,    65,    77,    67,    61,    69,    -1,    71,    65,
      55,    67,    -1,    69,    77,    71,    61,    55,    -1,    -1,
      65,    -1,    67,    61,    69,    -1,    71,    65,    55,    67,
      -1,    69,    -1,    71,    61,    55,    -1,    -1,    65,    -1,
      67,    61,    69,    -1,    71,    65,    55,    67,    -1,    69,
      -1,    71,    61,    55,    -1,    -1,    65,    -1,    67,    61,
      69,    -1,    71,    65,    55,    67,    -1,    69,    -1,    71,
      61,    55,    -1,    -1,    65,    -1,    67,    61,    69,    -1,
      71,    65,    55,    67,    -1,    69,    -1,    71,    61,    55,
      -1,    -1,    65,    -1,    67,    61,    69,    -1,    71,    65,
      55,    67,    -1,    69,    -1,    71,    61,    55,    -1,    -1,
      65,    -1,    67,    61,    69,    -1,    71,    65,    55,    67,
      -1,    69,    -1,    71,    61,    55,    -1,    -1,    65,    -1,
      67,    61,    69,    -1,    71,    65,    55,    67,    -1,    69,
      -1,    71,    61,    55,    55,    -1,    65,    -1,    67,    61,
      69,    -1,    71,    65,    65,    67,    67,    69,    69,    71,
      71
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     5,     8,    12,    16,    21,    24,    25,    28,    36,
      40,    44,    51,    53,    54,    58,    59,    94,    95,    96,
      97,   100,   101,   107,    58,   111,   112,    58,    47,     3,
       7,    11,    13,    14,    17,    18,    23,    26,    30,    32,
      33,    37,    38,    39,    41,    42,    43,    48,    49,    57,
      58,    63,    67,   105,   106,   114,   117,    58,    58,    58,
      58,   108,    58,   113,     4,    56,    58,    71,   109,   110,
      57,    58,    98,    99,    96,     0,    95,    19,    50,    52,
     114,    63,    77,     9,    58,    63,    63,    63,    63,    63,
      63,    63,    63,    63,    63,    63,    63,    63,    63,    63,
      63,    63,    63,    63,    63,   114,   114,    15,    45,     6,
      35,    20,    22,    27,    31,    34,    55,    65,    67,    69,
      71,    73,     9,    73,    77,    77,    58,    77,    73,    77,
      99,    95,    58,   105,   105,    46,   114,   111,   114,    16,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,    69,
     114,    61,   107,   107,   106,   106,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   108,
     113,   109,    57,    99,    73,    61,    77,    61,    61,    61,
      61,    77,    61,    61,    61,    61,    77,    77,    61,    61,
      61,    61,    61,    61,    61,    61,    77,    61,    77,    15,
      63,   103,   104,   114,   114,   114,   114,   115,   114,   116,
     114,    69,   114,   107,   114,    77,     9,    47,    77,   102,
      61,    61,    77,    61,    77,    61,    61,    61,    61,    77,
     104,   114,   114,   114,   104,   115,   116,   114,    47,     9,
      77,   114,   114,   114,    61
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    93,    94,    95,    95,    95,    96,    96,    96,    96,
      96,    96,    96,    97,    97,    97,    98,    98,    99,    99,
      99,   100,   101,   101,   101,   101,   101,   101,   102,   102,
     102,   103,   104,   104,   104,   104,   105,   105,   105,   106,
     106,   106,   106,   106,   106,   107,   107,   107,   107,   107,
     107,   107,   107,   107,   107,   107,   108,   108,   109,   109,
     110,   110,   110,   110,   111,   111,   112,   112,   113,   113,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     115,   115,   116,   116,   117,   117,   117,   117
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     3,     0,     1,     1,     1,     1,
       1,     2,     1,     4,     4,     6,     1,     3,     3,     2,
       1,     2,     1,     3,     3,     3,     5,     6,     4,     4,
       2,     7,     3,     3,     1,     1,     1,     3,     3,     3,
       3,     3,     3,     3,     3,     4,     4,     4,     3,     4,
       2,     2,     2,     2,     2,     1,     3,     1,     3,     1,
       1,     2,     1,     0,     3,     1,     4,     6,     3,     1,
       1,     1,     3,     3,     3,     2,     3,     3,     3,     1,
       1,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     6,     4,     4,     4,     4,     4,     4,     6,     6,
       3,     1,     3,     1,     4,     6,     6,     6
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* program: prog  */
#line 94 "cupl.y"
                                        {interpret((yyvsp[0].node));}
#line 1672 "y.tab.c"
    break;

  case 3: /* prog: command prog  */
#line 98 "cupl.y"
                {
		    (yyval.node) = cons(STATEMENT, (yyvsp[-1].node), (yyvsp[0].node));
#ifdef PARSEDEBUG
		    (yyval.node)->number = ++statement_count;
#endif /* PARSEDEBUG */
		}
#line 1683 "y.tab.c"
    break;

  case 4: /* prog: IDENTIFIER command prog  */
#line 105 "cupl.y"
                {
		    (yyval.node) = cons(STATEMENT, cons(LABEL, (yyvsp[-2].node), (yyvsp[-1].node)), (yyvsp[0].node));
#ifdef PARSEDEBUG
		    (yyval.node)->number = ++statement_count;
#endif /* PARSEDEBUG */
		}
#line 1694 "y.tab.c"
    break;

  case 5: /* prog: %empty  */
#line 112 "cupl.y"
                {(yyval.node) = (node *)NULL;}
#line 1700 "y.tab.c"
    break;

  case 6: /* command: simple  */
#line 117 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1706 "y.tab.c"
    break;

  case 7: /* command: cond  */
#line 118 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1712 "y.tab.c"
    break;

  case 8: /* command: perform  */
#line 119 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1718 "y.tab.c"
    break;

  case 9: /* command: BLOCK  */
#line 120 "cupl.y"
                                        {(yyval.node) = cons(BLOCK, NULLNODE, NULLNODE);}
#line 1724 "y.tab.c"
    break;

  case 10: /* command: END  */
#line 121 "cupl.y"
                                        {(yyval.node) = cons(END, NULLNODE, NULLNODE);}
#line 1730 "y.tab.c"
    break;

  case 11: /* command: DATA datal  */
#line 122 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1736 "y.tab.c"
    break;

  case 12: /* command: TITLE  */
#line 123 "cupl.y"
                                        {(yyval.node) = cons(WRITE, (yyvsp[0].node), NULLNODE);;}
#line 1742 "y.tab.c"
    break;

  case 13: /* cond: IF guard THEN simple  */
#line 127 "cupl.y"
                {(yyval.node) = cons(IF, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1748 "y.tab.c"
    break;

  case 14: /* cond: IF guard ELSE simple  */
#line 129 "cupl.y"
                {(yyval.node) = cons(IFELSE, (yyvsp[-2].node), cons(THEN, (yyvsp[0].node), (node *)NULL));}
#line 1754 "y.tab.c"
    break;

  case 15: /* cond: IF guard THEN simple ELSE simple  */
#line 131 "cupl.y"
                {(yyval.node) = cons(IFELSE, (yyvsp[-4].node), cons(THEN, (yyvsp[-2].node), (yyvsp[0].node)));}
#line 1760 "y.tab.c"
    break;

  case 16: /* ditem: NUMBER  */
#line 134 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1766 "y.tab.c"
    break;

  case 17: /* ditem: IDENTIFIER '=' NUMBER  */
#line 135 "cupl.y"
                                        {(yyval.node) = cons(LET,(yyvsp[-2].node), (yyvsp[0].node));}
#line 1772 "y.tab.c"
    break;

  case 18: /* datal: ditem ',' datal  */
#line 138 "cupl.y"
                                        {(yyval.node) = cons(DATA, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1778 "y.tab.c"
    break;

  case 19: /* datal: ditem datal  */
#line 139 "cupl.y"
                                        {(yyval.node) = cons(DATA, (yyvsp[-1].node), (yyvsp[0].node));}
#line 1784 "y.tab.c"
    break;

  case 20: /* datal: ditem  */
#line 140 "cupl.y"
                                        {(yyval.node) = cons(DATA, (yyvsp[0].node), NULLNODE);}
#line 1790 "y.tab.c"
    break;

  case 21: /* gosub: PERFORM IDENTIFIER  */
#line 143 "cupl.y"
                                        {(yyval.node) = cons(PERFORM, (yyvsp[0].node), NULLNODE);}
#line 1796 "y.tab.c"
    break;

  case 22: /* perform: gosub  */
#line 146 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1802 "y.tab.c"
    break;

  case 23: /* perform: gosub expr TIMES  */
#line 147 "cupl.y"
                                        {(yyval.node) = cons(TIMES, (yyvsp[-1].node), (yyvsp[-2].node));}
#line 1808 "y.tab.c"
    break;

  case 24: /* perform: gosub WHILE guard  */
#line 148 "cupl.y"
                                        {(yyval.node) = cons(WHILE, (yyvsp[0].node), (yyvsp[-2].node));}
#line 1814 "y.tab.c"
    break;

  case 25: /* perform: gosub UNTIL guard  */
#line 149 "cupl.y"
                                        {(yyval.node) = cons(UNTIL, (yyvsp[0].node), (yyvsp[-2].node));}
#line 1820 "y.tab.c"
    break;

  case 26: /* perform: gosub FOR IDENTIFIER '=' expl  */
#line 152 "cupl.y"
                {(yyval.node) = cons(FOR,   cons('=', (yyvsp[-2].node), (yyvsp[0].node)),                     (yyvsp[-4].node));}
#line 1826 "y.tab.c"
    break;

  case 27: /* perform: gosub FOR IDENTIFIER '=' expr iter  */
#line 154 "cupl.y"
                {(yyval.node) = cons(FOR,   cons(ITERATE, (yyvsp[-3].node), cons(FROM, (yyvsp[-1].node), (yyvsp[0].node))), (yyvsp[-5].node));}
#line 1832 "y.tab.c"
    break;

  case 28: /* iter: TO expr BY expr  */
#line 157 "cupl.y"
                                        {(yyval.node) = cons(TO, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1838 "y.tab.c"
    break;

  case 29: /* iter: BY expr TO expr  */
#line 158 "cupl.y"
                                        {(yyval.node) = cons(TO, (yyvsp[0].node), (yyvsp[-2].node));}
#line 1844 "y.tab.c"
    break;

  case 30: /* iter: TO expr  */
#line 159 "cupl.y"
                                        {(yyval.node) = cons(TO, (yyvsp[0].node), (node *)NULL);}
#line 1850 "y.tab.c"
    break;

  case 31: /* triple: '(' expr ',' expr ',' expr ')'  */
#line 163 "cupl.y"
                {(yyval.node) = cons(TRIPLE, (yyvsp[-5].node), cons(ITERATE, (yyvsp[-3].node), (yyvsp[-1].node)));}
#line 1856 "y.tab.c"
    break;

  case 32: /* expl: expr ',' expl  */
#line 166 "cupl.y"
                                        {(yyval.node) = cons(FORLIST, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1862 "y.tab.c"
    break;

  case 33: /* expl: triple ',' expl  */
#line 167 "cupl.y"
                                        {(yyval.node) = cons(FORLIST, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1868 "y.tab.c"
    break;

  case 34: /* expl: expr  */
#line 168 "cupl.y"
                                        {(yyval.node) = cons(FORLIST, (yyvsp[0].node), NULLNODE);}
#line 1874 "y.tab.c"
    break;

  case 35: /* expl: triple  */
#line 169 "cupl.y"
                                        {(yyval.node) = cons(FORLIST, (yyvsp[0].node), NULLNODE);}
#line 1880 "y.tab.c"
    break;

  case 36: /* guard: rel  */
#line 178 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1886 "y.tab.c"
    break;

  case 37: /* guard: rel AND rel  */
#line 179 "cupl.y"
                                        {(yyval.node) = cons(AND, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1892 "y.tab.c"
    break;

  case 38: /* guard: rel OR rel  */
#line 180 "cupl.y"
                                        {(yyval.node) = cons(OR,  (yyvsp[-2].node), (yyvsp[0].node));}
#line 1898 "y.tab.c"
    break;

  case 39: /* rel: expr '=' expr  */
#line 183 "cupl.y"
                                        {(yyval.node) = cons('=', (yyvsp[-2].node), (yyvsp[0].node));}
#line 1904 "y.tab.c"
    break;

  case 40: /* rel: expr NE expr  */
#line 184 "cupl.y"
                                        {(yyval.node) = cons(NE,  (yyvsp[-2].node), (yyvsp[0].node));}
#line 1910 "y.tab.c"
    break;

  case 41: /* rel: expr LE expr  */
#line 185 "cupl.y"
                                        {(yyval.node) = cons(LE,  (yyvsp[-2].node), (yyvsp[0].node));}
#line 1916 "y.tab.c"
    break;

  case 42: /* rel: expr GE expr  */
#line 186 "cupl.y"
                                        {(yyval.node) = cons(GE,  (yyvsp[-2].node), (yyvsp[0].node));}
#line 1922 "y.tab.c"
    break;

  case 43: /* rel: expr LT expr  */
#line 187 "cupl.y"
                                        {(yyval.node) = cons(LT,  (yyvsp[-2].node), (yyvsp[0].node));}
#line 1928 "y.tab.c"
    break;

  case 44: /* rel: expr GT expr  */
#line 188 "cupl.y"
                                        {(yyval.node) = cons(GT,  (yyvsp[-2].node), (yyvsp[0].node));}
#line 1934 "y.tab.c"
    break;

  case 45: /* simple: LET IDENTIFIER '=' expr  */
#line 193 "cupl.y"
                                        {(yyval.node) = cons(LET, (yyvsp[-2].node), (yyvsp[0].node));}
#line 1940 "y.tab.c"
    break;

  case 46: /* simple: INC IDENTIFIER BY expr  */
#line 194 "cupl.y"
                                        {(yyval.node) = cons(LET, (yyvsp[-2].node), cons(PLUS,  (yyvsp[-2].node), (yyvsp[0].node)));}
#line 1946 "y.tab.c"
    break;

  case 47: /* simple: DEC IDENTIFIER BY expr  */
#line 195 "cupl.y"
                                        {(yyval.node) = cons(LET, (yyvsp[-2].node), cons(MINUS, (yyvsp[-2].node), (yyvsp[0].node)));}
#line 1952 "y.tab.c"
    break;

  case 48: /* simple: GO TO IDENTIFIER  */
#line 196 "cupl.y"
                                        {(yyval.node) = cons(GO, (yyvsp[0].node), NULLNODE);}
#line 1958 "y.tab.c"
    break;

  case 49: /* simple: GO TO IDENTIFIER END  */
#line 197 "cupl.y"
                                        {(yyval.node) = cons(OG, (yyvsp[-1].node), NULLNODE);}
#line 1964 "y.tab.c"
    break;

  case 50: /* simple: READ readl  */
#line 198 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1970 "y.tab.c"
    break;

  case 51: /* simple: WRITE ALL  */
#line 199 "cupl.y"
                                        {(yyval.node) = cons(WRITE, cons(ALL, NULLNODE, NULLNODE), NULLNODE);}
#line 1976 "y.tab.c"
    break;

  case 52: /* simple: WRITE writel  */
#line 200 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1982 "y.tab.c"
    break;

  case 53: /* simple: ALLOCATE allocl  */
#line 201 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1988 "y.tab.c"
    break;

  case 54: /* simple: WATCH varlist  */
#line 202 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 1994 "y.tab.c"
    break;

  case 55: /* simple: STOP  */
#line 203 "cupl.y"
                                        {(yyval.node) = cons(STOP, NULLNODE, NULLNODE);}
#line 2000 "y.tab.c"
    break;

  case 56: /* readl: IDENTIFIER ',' readl  */
#line 206 "cupl.y"
                                        {(yyval.node) = cons(READ, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2006 "y.tab.c"
    break;

  case 57: /* readl: IDENTIFIER  */
#line 207 "cupl.y"
                                        {(yyval.node) = cons(READ, (yyvsp[0].node), NULLNODE);}
#line 2012 "y.tab.c"
    break;

  case 58: /* writel: witem ',' writel  */
#line 210 "cupl.y"
                                        {(yyval.node) = cons(WRITE, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2018 "y.tab.c"
    break;

  case 59: /* writel: witem  */
#line 211 "cupl.y"
                                        {(yyval.node) = cons(WRITE, (yyvsp[0].node), NULLNODE);}
#line 2024 "y.tab.c"
    break;

  case 60: /* witem: IDENTIFIER  */
#line 214 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 2030 "y.tab.c"
    break;

  case 61: /* witem: '/' IDENTIFIER  */
#line 215 "cupl.y"
                                        {(yyval.node) = cons(FWRITE, (yyvsp[0].node), NULLNODE);}
#line 2036 "y.tab.c"
    break;

  case 62: /* witem: STRING  */
#line 216 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 2042 "y.tab.c"
    break;

  case 63: /* witem: %empty  */
#line 217 "cupl.y"
                                        {(yyval.node) = (node *)NULL;}
#line 2048 "y.tab.c"
    break;

  case 64: /* allocl: alloc ',' allocl  */
#line 220 "cupl.y"
                                        {(yyval.node) = cons(VARLIST, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2054 "y.tab.c"
    break;

  case 65: /* allocl: alloc  */
#line 221 "cupl.y"
                                        {(yyval.node) = cons(VARLIST, (yyvsp[0].node), NULLNODE);}
#line 2060 "y.tab.c"
    break;

  case 66: /* alloc: IDENTIFIER '(' expr ')'  */
#line 225 "cupl.y"
                {(yyval.node) = cons(ALLOCATE, (yyvsp[-3].node), (yyvsp[-1].node));}
#line 2066 "y.tab.c"
    break;

  case 67: /* alloc: IDENTIFIER '(' expr ',' expr ')'  */
#line 227 "cupl.y"
                {(yyval.node) = cons(ALLOCATE, (yyvsp[-5].node), cons(DIMENSION, (yyvsp[-3].node), (yyvsp[-1].node)));}
#line 2072 "y.tab.c"
    break;

  case 68: /* varlist: IDENTIFIER ',' varlist  */
#line 230 "cupl.y"
                                        {(yyval.node) = cons(WATCH, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2078 "y.tab.c"
    break;

  case 69: /* varlist: IDENTIFIER  */
#line 231 "cupl.y"
                                        {(yyval.node) = cons(WATCH, (yyvsp[0].node), NULLNODE);}
#line 2084 "y.tab.c"
    break;

  case 70: /* expr: NUMBER  */
#line 236 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 2090 "y.tab.c"
    break;

  case 71: /* expr: IDENTIFIER  */
#line 237 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 2096 "y.tab.c"
    break;

  case 72: /* expr: '(' expr ')'  */
#line 239 "cupl.y"
                                        {(yyval.node) = (yyvsp[-1].node);}
#line 2102 "y.tab.c"
    break;

  case 73: /* expr: expr '+' expr  */
#line 240 "cupl.y"
                                        {(yyval.node) = cons(PLUS, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2108 "y.tab.c"
    break;

  case 74: /* expr: expr '-' expr  */
#line 241 "cupl.y"
                                        {(yyval.node) = cons(MINUS, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2114 "y.tab.c"
    break;

  case 75: /* expr: '-' expr  */
#line 242 "cupl.y"
                                        {(yyval.node) = cons(UMINUS, NULLNODE, (yyvsp[0].node));}
#line 2120 "y.tab.c"
    break;

  case 76: /* expr: expr '*' expr  */
#line 243 "cupl.y"
                                        {(yyval.node) = cons(MULTIPLY, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2126 "y.tab.c"
    break;

  case 77: /* expr: expr '/' expr  */
#line 244 "cupl.y"
                                        {(yyval.node) = cons(DIVIDE, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2132 "y.tab.c"
    break;

  case 78: /* expr: expr POWER expr  */
#line 245 "cupl.y"
                                        {(yyval.node) = cons(POWER, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2138 "y.tab.c"
    break;

  case 79: /* expr: IDN  */
#line 247 "cupl.y"
                                        {(yyval.node) = cons(IDN, NULLNODE, NULLNODE);}
#line 2144 "y.tab.c"
    break;

  case 80: /* expr: subscr  */
#line 248 "cupl.y"
                                        {(yyval.node) = (yyvsp[0].node);}
#line 2150 "y.tab.c"
    break;

  case 81: /* expr: ABS '(' expr ')'  */
#line 250 "cupl.y"
                                        {(yyval.node) = cons(ABS, NULLNODE, (yyvsp[-1].node));}
#line 2156 "y.tab.c"
    break;

  case 82: /* expr: ATAN '(' expr ')'  */
#line 251 "cupl.y"
                                        {(yyval.node) = cons(ATAN, NULLNODE, (yyvsp[-1].node));}
#line 2162 "y.tab.c"
    break;

  case 83: /* expr: COS '(' expr ')'  */
#line 252 "cupl.y"
                                        {(yyval.node) = cons(COS, NULLNODE, (yyvsp[-1].node));}
#line 2168 "y.tab.c"
    break;

  case 84: /* expr: EXP '(' expr ')'  */
#line 253 "cupl.y"
                                        {(yyval.node) = cons(EXP, NULLNODE, (yyvsp[-1].node));}
#line 2174 "y.tab.c"
    break;

  case 85: /* expr: FLOOR '(' expr ')'  */
#line 254 "cupl.y"
                                        {(yyval.node) = cons(FLOOR, NULLNODE, (yyvsp[-1].node));}
#line 2180 "y.tab.c"
    break;

  case 86: /* expr: LOG '(' expr ')'  */
#line 255 "cupl.y"
                                        {(yyval.node) = cons(LOG, NULLNODE, (yyvsp[-1].node));}
#line 2186 "y.tab.c"
    break;

  case 87: /* expr: SQRT '(' expr ')'  */
#line 256 "cupl.y"
                                        {(yyval.node) = cons(SQRT, NULLNODE, (yyvsp[-1].node));}
#line 2192 "y.tab.c"
    break;

  case 88: /* expr: SIN '(' expr ')'  */
#line 257 "cupl.y"
                                        {(yyval.node) = cons(SIN, NULLNODE, (yyvsp[-1].node));}
#line 2198 "y.tab.c"
    break;

  case 89: /* expr: RAND '(' expr ')'  */
#line 258 "cupl.y"
                                        {(yyval.node) = cons(RAND, NULLNODE, (yyvsp[-1].node));}
#line 2204 "y.tab.c"
    break;

  case 90: /* expr: DET '(' expr ')'  */
#line 259 "cupl.y"
                                        {(yyval.node) = cons(DET, NULLNODE, (yyvsp[-1].node));}
#line 2210 "y.tab.c"
    break;

  case 91: /* expr: DOT '(' expr ',' expr ')'  */
#line 260 "cupl.y"
                                        {(yyval.node) = cons(DOT, (yyvsp[-3].node), (yyvsp[-1].node));}
#line 2216 "y.tab.c"
    break;

  case 92: /* expr: INV '(' expr ')'  */
#line 261 "cupl.y"
                                        {(yyval.node) = cons(INV, NULLNODE, (yyvsp[-1].node));}
#line 2222 "y.tab.c"
    break;

  case 93: /* expr: POSMAX '(' expr ')'  */
#line 262 "cupl.y"
                                        {(yyval.node) = cons(POSMAX, NULLNODE, (yyvsp[-1].node));}
#line 2228 "y.tab.c"
    break;

  case 94: /* expr: POSMIN '(' expr ')'  */
#line 263 "cupl.y"
                                        {(yyval.node) = cons(POSMIN, NULLNODE, (yyvsp[-1].node));}
#line 2234 "y.tab.c"
    break;

  case 95: /* expr: SGM '(' expr ')'  */
#line 264 "cupl.y"
                                        {(yyval.node) = cons(SGM, NULLNODE, (yyvsp[-1].node));}
#line 2240 "y.tab.c"
    break;

  case 96: /* expr: TRC '(' expr ')'  */
#line 265 "cupl.y"
                                        {(yyval.node) = cons(TRC, NULLNODE, (yyvsp[-1].node));}
#line 2246 "y.tab.c"
    break;

  case 97: /* expr: TRN '(' expr ')'  */
#line 266 "cupl.y"
                                        {(yyval.node) = cons(TRN, NULLNODE, (yyvsp[-1].node));}
#line 2252 "y.tab.c"
    break;

  case 98: /* expr: MAX '(' expr ',' maxl ')'  */
#line 268 "cupl.y"
                                        {(yyval.node) = cons(MAX, (yyvsp[-3].node), (yyvsp[-1].node));}
#line 2258 "y.tab.c"
    break;

  case 99: /* expr: MIN '(' expr ',' minl ')'  */
#line 269 "cupl.y"
                                        {(yyval.node) = cons(MIN, (yyvsp[-3].node), (yyvsp[-1].node));}
#line 2264 "y.tab.c"
    break;

  case 100: /* maxl: expr ',' maxl  */
#line 272 "cupl.y"
                                        {(yyval.node) = cons(MAX, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2270 "y.tab.c"
    break;

  case 101: /* maxl: expr  */
#line 273 "cupl.y"
                                        {(yyval.node) = cons(MAX, (yyvsp[0].node), NULLNODE);}
#line 2276 "y.tab.c"
    break;

  case 102: /* minl: expr ',' minl  */
#line 276 "cupl.y"
                                        {(yyval.node) = cons(MIN, (yyvsp[-2].node), (yyvsp[0].node));}
#line 2282 "y.tab.c"
    break;

  case 103: /* minl: expr  */
#line 277 "cupl.y"
                                        {(yyval.node) = cons(MIN, (yyvsp[0].node), NULLNODE);}
#line 2288 "y.tab.c"
    break;

  case 104: /* subscr: IDENTIFIER '(' expr ')'  */
#line 281 "cupl.y"
                {(yyval.node) = cons(SUBSCRIPT, (yyvsp[-3].node), (yyvsp[-1].node));}
#line 2294 "y.tab.c"
    break;

  case 105: /* subscr: IDENTIFIER '(' expr ',' expr ')'  */
#line 283 "cupl.y"
                {(yyval.node) = cons(SUBSCRIPT, (yyvsp[-5].node), cons(DIMENSION, (yyvsp[-3].node), (yyvsp[-1].node)));}
#line 2300 "y.tab.c"
    break;

  case 106: /* subscr: IDENTIFIER '(' expr ',' '*' ')'  */
#line 285 "cupl.y"
                {(yyval.node) = cons(JSLICE, (yyvsp[-5].node), (yyvsp[-3].node));}
#line 2306 "y.tab.c"
    break;

  case 107: /* subscr: IDENTIFIER '(' '*' ',' expr ')'  */
#line 287 "cupl.y"
                {(yyval.node) = cons(ISLICE, (yyvsp[-5].node), (yyvsp[-1].node));}
#line 2312 "y.tab.c"
    break;


#line 2316 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 289 "cupl.y"


node *cons(op, left, right)
/* make a cons for a binary operation */
int	op;		/* opcode */
node	*left, *right;	/* child nodes */
{
    node	*new;

    /* get a node */
    if ((new = (node *)malloc(sizeof(node))) == (node *)NULL)
    {
	(void) puts(NOMEM);
	exit(1);
    }

    new->type = op;
    new->u.n.left = left;
    new->u.n.right = right;

#ifdef PARSEDEBUG
    if (verbose >= DEBUG_ALLOCATE)
	(void) printf("cons:   %p -> %p %p (%s)\n",
		      new, left, right, tokdump(op));
#endif /* PARSEDEBUG */

    return(new);
}

/* cupl.y ends here */
