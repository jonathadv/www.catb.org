/*
 * Items: acosh(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <math.h>

main(int arg, char **argv)
{
    acosh(-23.0);
}
