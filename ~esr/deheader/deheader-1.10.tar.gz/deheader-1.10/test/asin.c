/*
 * Items: asin(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <math.h>

main(int arg, char **argv)
{
    asin(-23.0);
}
