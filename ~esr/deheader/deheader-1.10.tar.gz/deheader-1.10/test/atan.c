/*
 * Items: atan(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <math.h>

main(int arg, char **argv)
{
    atan(-23.0);
}
