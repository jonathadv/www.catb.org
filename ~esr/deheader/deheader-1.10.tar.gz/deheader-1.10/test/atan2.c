/*
 * Items: atan2(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <math.h>

main(int arg, char **argv)
{
    atan2(-23.0, 17.0);
}
