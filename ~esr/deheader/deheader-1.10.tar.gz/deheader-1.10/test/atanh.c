/*
 * Items: atanh(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <math.h>

main(int arg, char **argv)
{
    atanh(-23.0);
}
