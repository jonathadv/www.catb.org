/*
 * Items: atoll(, l64a(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <stdlib.h>

main(int arg, char **argv)
{
    (void) atol("2317");

}
