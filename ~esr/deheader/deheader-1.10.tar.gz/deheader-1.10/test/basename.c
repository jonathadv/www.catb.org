/*
 * Items: basename(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <libgen.h>

main(int arg, char **argv)
{
    (void)basename("/dev/null");
}
