/*
 * Items: bcopy(
 * Standardized-By: SuS
 * Detected-by: gcc-4.4.3 + Linux
 */

#include <strings.h>

main(int arg, char **argv)
{
    (void) bcopy(0, 0, 0);
}
