/*
 * Items: btowc(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <stdio.h>
#include <wchar.h>

main(int arg, char **argv)
{
    (void)btowc('a');
}
