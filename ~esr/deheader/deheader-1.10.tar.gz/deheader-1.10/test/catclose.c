/*
 * Items: catclose(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <nl_types.h>

main(int arg, char **argv)
{
    (void) catclose(0);
}
