/*
 * Items: catopen(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <nl_types.h>

main(int arg, char **argv)
{
    (void) catopen("foobar", 0);
}
