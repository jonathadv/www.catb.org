/* this file tests detection of duplicate heafers */

#include <stdio.h>
#include <stdio.h>

main(int arg, char **argv)
{
}
