/*
 * Items: fstat(
 * Standardized-By: SuS
 * Not-Detected-by: gcc-4.4.3 + Linux
 */

#include <sys/stat.h>
#include <sys/types.h>

main(int arg, char **argv)
{
    fstat(0, 0);
}
