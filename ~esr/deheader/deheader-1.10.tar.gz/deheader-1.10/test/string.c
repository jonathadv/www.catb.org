/* this file has string.h but doesn't need it */

#include <string.h>

main(int arg, char **argv)
{
}
