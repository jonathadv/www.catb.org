# Julia: SLOC=3 LLOC=0
println("""hello
multiline 
world""")
