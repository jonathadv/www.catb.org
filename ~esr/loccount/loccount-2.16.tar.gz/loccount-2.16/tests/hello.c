// C: SLOC=6 LLOC=2
#include <stdio.h>

int main()
{
   printf("Hello, World!");
   return 0;
}
