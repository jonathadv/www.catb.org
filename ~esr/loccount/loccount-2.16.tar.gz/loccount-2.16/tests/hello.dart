// Dart: SLOC=3 LLOC=1
main() {
  print('Hello World!');
}
