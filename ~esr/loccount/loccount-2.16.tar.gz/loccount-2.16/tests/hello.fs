// F#: SLOC=2 LLOC=0
open System
Console.WriteLine("Hello World!")
