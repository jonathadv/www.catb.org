// Kotlin: SLOC=3 LLOC=0
fun main(args: Array<String>) {
   val scope = "World"
   println("Hello, $scope!")
}
