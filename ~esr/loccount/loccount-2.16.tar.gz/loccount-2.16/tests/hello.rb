# Ruby: SLOC=1 LLOC=0
print "Hello, World!\n"
