#!/bin/sh
# shell: SLOC=1 LLOC=0
# Should be counted as one line
echo "Hello world"
