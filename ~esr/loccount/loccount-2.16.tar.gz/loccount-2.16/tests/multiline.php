<?php
// PHP: SLOC=11 LLOC=3

function foo() {
  $foo = '//  might
/*  consider
"   comments
*/  and
"   quotes
';
  echo $foo . "\n";
}

foo();
