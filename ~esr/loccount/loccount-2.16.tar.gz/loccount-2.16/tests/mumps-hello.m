; MUMPS: SLOC=3 LLOC=0
; and not be misidentified as Objective C
hello()
  write "Hello, World!",!
  quit
