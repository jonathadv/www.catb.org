# Perl: SLOC=1 LLOC=0
print "Hello, world!"

# The following is POD documentation; it should not be counted:
=head1 Test
=head2 testing
=cut

__END__
# The following should not be counted in a line-counting program:
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
print "Hello!\n";
