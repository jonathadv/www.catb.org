// Go: SLOC=4 LLOC=0
package newline

func foo() string {
	return `" `
}
