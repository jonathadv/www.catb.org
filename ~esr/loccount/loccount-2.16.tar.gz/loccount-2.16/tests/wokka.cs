/* C#: SLOC=5 LLOC=1 */

class Test {
  static void Main() {
    System.Console.WriteLine("Hello, World (in C#)");
  }
}
