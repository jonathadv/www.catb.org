// SPDX-FileCopyrightText: (C) The MADness project
// SPDX-License-Identifier: MIT-0
#include <stdio.h>
#include <stdint.h>

#include <ctss.h>

int64_t chncom (int64_t arg)
{
   exit (arg);
}
int64_t Cexit (int64_t arg)
{
   exit (arg);
}
