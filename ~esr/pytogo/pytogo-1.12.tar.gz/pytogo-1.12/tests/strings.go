//# Test single-quote conversion in strings
// SPDX-FileCopyrightText: (C) Eric S. Raymond <esr@thyrsus.com>
// SPDX-License-Identifier: BSD-2-Clause
"foo"       // Should not change
"bar"       // Single quotes should become double
'foo\"bar'  // Only outermost double quotes should change
'hi"there'  // Embedded double quote should prevent change
"foo" "bar" // Second literal should change
"foo" "bar" // First literal should change
