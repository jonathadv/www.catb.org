/* Compiled by kvik */
#include "kvik_obj_header.h"
#include "k.state.c"
set_dp(&d[0], 500, 0);
p[0] = 1000;
p[1] = 540;
gd = p[1]; break;
case 1000:
#include "kvik_obj_tail.h"
/* end */
