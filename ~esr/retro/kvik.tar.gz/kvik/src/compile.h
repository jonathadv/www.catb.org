/** compile.h
 ** Header file for main compilation routines.
 ** Written by Asher Hoskins, 29/10/94
 **/

#define MAXLINELENGTH 132

void start_compile(FILE *, int, char **);
void compile_line(char *, FILE *, int);
void end_compile(FILE *);

