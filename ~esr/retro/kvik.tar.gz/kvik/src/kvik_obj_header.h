/* Header for kvik output code, written by Asher Hoskins, 30/10/94 */

#include <stdio.h>
#include "../src/kvikmath.h"
#include "kvik_obj_types.h"
#include "../src/kviksl.h"

#define CONST0 (52767)
#define CONST1 (1)
#define CONST2 (OVERFLOW)
#define CONST3 (6366)
#define CONST4 (13863)
#define CONST5 (625)
#define CONST6 (14142)
#define CONST7 (17320)
#define CONST8 (6020)
#define CONST9 (19999)

data_area_t *data = NULL;

void main(void)
{
	int r[10];		/* Registers */
	int p[10];		/* Program pointers */
	dp_t d[10];		/* Data pointers */
	kviknum *store;
	int gd, i;

	/* A little bit of initialisation... */
	for (i=0; i<10; i++) {
		r[i] = 0;
		p[i] = -3;
		d[i].start = NULL;
	}

	gd = -1;
	do {
		switch(gd) {
		case -1:			/* start */

/* User code follows: */

