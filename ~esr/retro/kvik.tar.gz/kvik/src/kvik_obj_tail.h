/* Tail for kvik output code, Written by Asher Hoskins, 30/10/94 */

			gd = -2; break;

		case -3:
			puts("KVIK: JUMPED USING UNINITIALISED PROGRAM POINTER");
			exit(1);
		default:
			if (!stdlib(gd, r, p, d, &gd)) {
				printf("KVIK: NO LABEL CALLED %d\n", gd);
				exit(1);
			}
		}

	} while (gd != -2);

	printf("\nKVIK FINISHED\n");
}

