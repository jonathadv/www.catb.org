/* Types used in kvik produced code, Written by Asher Hoskins, 30/10/94 */

typedef struct {
	unsigned int id;
	kviknum *start;
	unsigned int offset;
	unsigned int size;
} dp_t;

typedef struct data_area {
	unsigned int id;
	kviknum *start;
	unsigned int size;
	struct data_area *next;
} data_area_t;

