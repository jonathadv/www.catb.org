/** kvikmath.h
 ** Header file for kvik math routines.
 ** Written by Asher Hoskins, 29/10/94
 **/

#define OVERFLOW (0xffff)

typedef unsigned int kviknum;

kviknum str2kvik(char *);
kviknum negate(kviknum);
double kvik2doub(kviknum);
kviknum doub2kvik(double);

