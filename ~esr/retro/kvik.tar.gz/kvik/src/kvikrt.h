/** kvikrt.h
 ** Header file for kvik runtime routines.
 ** Written by Asher Hoskins, 30/10/94.
 **/

kviknum *alloc_storage(unsigned int, unsigned int, int);
void set_dp(dp_t *, unsigned int, kviknum);
void set_dp_intoff(dp_t *, unsigned int, unsigned int);
void previous(dp_t *);
void next(dp_t *);
kviknum read_data(dp_t *);
void write_data(dp_t *, kviknum);
kviknum expr(int, kviknum, int, int, kviknum);
kviknum read_channel(int);
void write_channel(int, kviknum);
kviknum input_baudot(void);
void output_baudot(kviknum);

