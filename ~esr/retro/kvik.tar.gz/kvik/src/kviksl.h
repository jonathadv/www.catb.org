/** kviksl.h
 ** Header file for kvik standard library routines.
 ** Written by Asher Hoskins, 6/11/94
 **/

int stdlib(int, int *, int *, dp_t *, int *);

